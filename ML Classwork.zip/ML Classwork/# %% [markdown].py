# %% [markdown]
# I will work with this dataset:
# https://www.kaggle.com/datasets/umerrtx/machine-failure-prediction-using-sensor-data
# 
# This dataset contains sensor data collected from various machines, with the aim of predicting machine failures in advance. It includes a variety of sensor readings as well as the recorded machine failures.
# 
# The purpose is to detect with accuracy whether a machine will fail or not according to the provided sensory data.

# %% [markdown]
# Importing the libraries:

# %%
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
import seaborn as sns
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.model_selection import train_test_split, GridSearchCV, RepeatedStratifiedKFold,\
    RepeatedKFold, cross_val_score, cross_val_predict, KFold, cross_validate
from sklearn.preprocessing import Normalizer, MinMaxScaler, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn import svm
from sklearn import *
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix,\
    classification_report, roc_auc_score, roc_curve, auc, average_precision_score,\
    precision_recall_curve,PredictionErrorDisplay, mean_squared_error, log_loss
from sklearn.linear_model import LogisticRegressionCV
from sklearn.datasets import make_regression, make_classification
from sklearn.metrics import ConfusionMatrixDisplay
from sklearn.svm import SVC


# %% [markdown]
# Loading and getting to know the dataset:

# %%
dataset = pd.read_csv("/Users/skywalker/Documents/University/Year 3/Machine Learning/ML Classwork/data.csv")
dataset

# %% [markdown]
# EDA

# %%
dataset.describe()

# %% [markdown]
# Histograms

# %%
dataset.hist(figsize=(15, 10))
plt.show()

# %% [markdown]
# Augmenting the data to reach over 1000 rows

# %%
# Augmenting 200 rows by sampling with replacement and applying Gaussian noise
augmented_rows = 200

# Sample 200 rows with replacement
sampled_data = dataset.sample(n=augmented_rows, replace=True, random_state=42)

# Add Gaussian noise to numerical columns
numerical_columns = dataset.select_dtypes(include=['float64', 'int64']).columns
for column in numerical_columns:
    sampled_data[column] += np.random.normal(0, sampled_data[column].std() * 0.05, size=sampled_data[column].shape)

# Combine original and augmented data
augmented_dataset = pd.concat([dataset, sampled_data], ignore_index=True)

# Display the new shape of the dataset
print("Dataset shape after augmentation:", augmented_dataset.shape)

# Save the augmented dataset for later use (optional)
augmented_dataset.to_csv('augmented_data.csv', index=False)
print("Augmented dataset saved as 'augmented_data.csv'")

# %% [markdown]
# Re-import the new dataset and redo the EDA.

# %%
new_Dataset = pd.read_csv('/Users/skywalker/Documents/University/Year 3/Machine Learning/ML Classwork/augmented_data.csv')

# %% [markdown]
# New EDA

# %%
new_Dataset.describe()

# %% [markdown]
# Histograms for data distribution

# %%
new_Dataset.hist(figsize=(15, 10))
plt.show()

# %% [markdown]
# Correlation Matrix (Used to determine which features impact the target variable most)

# %%
correlationMatrix = new_Dataset.corr()
plt.figure(figsize=(10, 8))
sns.heatmap(correlationMatrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Matrix')
plt.show()

# %% [markdown]
# Using boxplots to determine outliers.

# %%
numerical_columns = new_Dataset.select_dtypes(include=['float64', 'int64']).columns
for column in numerical_columns:
    plt.figure(figsize=(8, 4))
    sns.boxplot(x=new_Dataset[column])
    plt.title(f"Boxplot of {column}")
    plt.show()

# %% [markdown]
# Pairplot to view correlation between each feature

# %%
sns.pairplot(new_Dataset)

# %% [markdown]
# Feature Importance

# %%
# Ensure the target variable is categorical
new_Dataset['fail'] = new_Dataset['fail'].astype(int)

# Scale and split the data
scaler = MinMaxScaler()
scaled_features = scaler.fit_transform(new_Dataset[['footfall', 'tempMode', 'AQ', 'USS', 'CS', 'VOC', 'RP', 'IP', 'Temperature']])
labels = new_Dataset['fail']
features_train, features_test, labels_train, labels_test = train_test_split(
    scaled_features, labels, test_size=0.3, random_state=42
)

# Train the Random Forest Classifier
rf_classifier = RandomForestClassifier(random_state=0)
rf_classifier.fit(features_train, labels_train)

# Compute permutation importance
perm_importance = permutation_importance(
    rf_classifier, features_test, labels_test, n_repeats=10, random_state=42, n_jobs=2
)

# Create a Series for feature importances
feature_names = ['footfall', 'tempMode', 'AQ', 'USS', 'CS', 'VOC', 'RP', 'IP', 'Temperature']
importance_scores = pd.Series(perm_importance.importances_mean, index=feature_names)

# Plot the feature importances
importance_scores.plot.bar(yerr=perm_importance.importances_std)
plt.title("Feature Importances using Permutation")
plt.ylabel("Mean Accuracy Decrease")
plt.tight_layout()
plt.show()

# %% [markdown]
# Based on the plot I will continue with the features: VOC, AQ, USS, CS. That is because these are the most importance features.

# %% [markdown]
# Preprocessing

# %%
# Select the features and target variable
selected_features = ['VOC', 'AQ', 'USS', 'CS']
data_preprocessed = new_Dataset[selected_features + ['fail']]

# Check for missing values and handle them
print("Missing values before preprocessing:")
print(data_preprocessed.isnull().sum())

# Fill missing values with the mean (if any)
data_preprocessed.fillna(data_preprocessed.mean(), inplace=True)

# Separate features and target
X_selected = data_preprocessed[selected_features]
y_selected = data_preprocessed['fail']

# Scale the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_selected)

# Split into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y_selected, test_size=0.3, random_state=42
)

# Confirm preprocessing is complete
print("Preprocessing complete.")
print(f"Training set size: {X_train.shape}")
print(f"Testing set size: {X_test.shape}")

# %% [markdown]
# Baseline Logistic Regression Model

# %%
baseline_model = LogisticRegression(random_state=42)
baseline_model.fit(X_train, y_train)

# Make predictions
y_pred_train = baseline_model.predict(X_train)
y_pred_test = baseline_model.predict(X_test)

# Evaluate performance on training and testing data
print("Training Set Performance:")
print(f"Accuracy: {accuracy_score(y_train, y_pred_train):.2f}")
print("Classification Report:\n", classification_report(y_train, y_pred_train))

print("Testing Set Performance:")
print(f"Accuracy: {accuracy_score(y_test, y_pred_test):.2f}")
print("Classification Report:\n", classification_report(y_test, y_pred_test))

# Confusion matrix for testing data
print("Confusion Matrix (Testing Set):")
print(confusion_matrix(y_test, y_pred_test))


# Plot the confusion matrix
ConfusionMatrixDisplay.from_predictions(
    y_test, y_pred_test, display_labels=["Non-Failure", "Failure"], cmap="Blues"
)
plt.title("Confusion Matrix")
plt.show()

# %% [markdown]
# Training a random forrest classifier

# %%
# Train the Random Forest Classifier
rf_model = RandomForestClassifier(random_state=42, n_estimators=100)
rf_model.fit(X_train, y_train)

# Make predictions
rf_y_pred_train = rf_model.predict(X_train)
rf_y_pred_test = rf_model.predict(X_test)

# Evaluate performance on training and testing data
print("Training Set Performance:")
print(f"Accuracy: {accuracy_score(y_train, rf_y_pred_train):.2f}")
print("Classification Report:\n", classification_report(y_train, rf_y_pred_train))

print("Testing Set Performance:")
print(f"Accuracy: {accuracy_score(y_test, rf_y_pred_test):.2f}")
print("Classification Report:\n", classification_report(y_test, rf_y_pred_test))

# Plot confusion matrix for testing data
ConfusionMatrixDisplay.from_predictions(
    y_test, rf_y_pred_test, display_labels=["Non-Failure", "Failure"], cmap="Blues"
)
plt.title("Confusion Matrix (Random Forest)")
plt.show()

# %% [markdown]
# Another random forrest run with parameter tuning to prevent overfitting

# %%
# Train a Random Forest Classifier with adjustments
rf_model_revised = RandomForestClassifier(
    random_state=42, 
    n_estimators=100,          # Number of trees
    max_depth=10,              # Limit tree depth to prevent overfitting
    min_samples_split=10,      # Minimum samples required to split a node
    min_samples_leaf=5,        # Minimum samples required in a leaf node
    max_features='sqrt'        # Limit number of features considered per split
)

# Fit the revised model
rf_model_revised.fit(X_train, y_train)

# Make predictions
rf_y_pred_train_revised = rf_model_revised.predict(X_train)
rf_y_pred_test_revised = rf_model_revised.predict(X_test)

# Evaluate the model with cross-validation
cv_scores = cross_val_score(rf_model_revised, X_scaled, y_selected, cv=5)
print("Cross-Validation Accuracy:", cv_scores.mean())

# Evaluate performance on training data
print("Revised Training Set Performance:")
print(f"Accuracy: {accuracy_score(y_train, rf_y_pred_train_revised):.2f}")
print("Classification Report:\n", classification_report(y_train, rf_y_pred_train_revised))

# Evaluate performance on testing data
print("Revised Testing Set Performance:")
print(f"Accuracy: {accuracy_score(y_test, rf_y_pred_test_revised):.2f}")
print("Classification Report:\n", classification_report(y_test, rf_y_pred_test_revised))

# Plot confusion matrix for testing data
ConfusionMatrixDisplay.from_predictions(
    y_test, rf_y_pred_test_revised, display_labels=["Non-Failure", "Failure"], cmap="Blues"
)
plt.title("Confusion Matrix (Revised Random Forest)")
plt.show()

# %% [markdown]
# The results suggest a less overfit model

# %% [markdown]
# I will proceed with an SVM model next. I will do a basic run then will do a tuned run and asses the results.

# %%
# Train a basic SVM model with RBF kernel
svm_model = SVC(kernel='rbf', random_state=42)
svm_model.fit(X_train, y_train)

# Make predictions
svm_y_pred_train = svm_model.predict(X_train)
svm_y_pred_test = svm_model.predict(X_test)

# Evaluate performance on training data
print("Training Set Performance:")
print(f"Accuracy: {accuracy_score(y_train, svm_y_pred_train):.2f}")
print("Classification Report:\n", classification_report(y_train, svm_y_pred_train))

# Evaluate performance on testing data
print("Testing Set Performance:")
print(f"Accuracy: {accuracy_score(y_test, svm_y_pred_test):.2f}")
print("Classification Report:\n", classification_report(y_test, svm_y_pred_test))

# Plot confusion matrix for testing data
ConfusionMatrixDisplay.from_predictions(
    y_test, svm_y_pred_test, display_labels=["Non-Failure", "Failure"], cmap="Blues"
)
plt.title("Confusion Matrix (SVM)")
plt.show()

# %% [markdown]
# Doing hyperparameter tuning with grid search for the SVM model.

# %%
# Define the parameter grid
param_grid = {
    'C': [0.1, 1, 10, 100],         # Regularization parameter
    'gamma': [1, 0.1, 0.01, 0.001], # Kernel coefficient for RBF kernel
    'kernel': ['rbf']               # Use only RBF kernel
}

# Initialize the SVC model
svm_model = SVC()

# Perform Grid Search with 5-fold cross-validation
grid_search = GridSearchCV(
    svm_model, param_grid, cv=5, scoring='accuracy', verbose=2, n_jobs=-1
)

# Fit the Grid Search to the training data
grid_search.fit(X_train, y_train)

# Display the best parameters and corresponding score
print("Best Parameters:", grid_search.best_params_)
print("Best Cross-Validation Accuracy:", grid_search.best_score_)

# Evaluate the best model on the testing set
best_svm_model = grid_search.best_estimator_
svm_y_pred_test_tuned = best_svm_model.predict(X_test)

# Testing set performance
print("Testing Set Performance:")
print(f"Accuracy: {accuracy_score(y_test, svm_y_pred_test_tuned):.2f}")
print("Classification Report:\n", classification_report(y_test, svm_y_pred_test_tuned))

# Plot confusion matrix for testing data
ConfusionMatrixDisplay.from_predictions(
    y_test, svm_y_pred_test_tuned, display_labels=["Non-Failure", "Failure"], cmap="Blues"
)
plt.title("Confusion Matrix (Tuned SVM)")
plt.show()

# %% [markdown]
# Models Comparison

# %%
# Collecting metrics for each model
model_metrics = {
    'Model': [
        'Logistic Regression',
        'Random Forest (Base)',
        'Random Forest (Tuned)',
        'SVM (Base)',
        'SVM (Tuned)'
    ],
    'Accuracy': [
        0.89,  # Logistic Regression
        0.90,  # Base Random Forest
        0.88,  # Tuned Random Forest
        0.91,  # Base SVM
        0.90   # Tuned SVM
    ],
    'Precision': [
        0.89,  # Logistic Regression
        0.89,  # Base Random Forest
        0.88,  # Tuned Random Forest
        0.90,  # Base SVM
        0.90   # Tuned SVM
    ],
    'Recall': [
        0.89,  # Logistic Regression
        0.89,  # Base Random Forest
        0.87,  # Tuned Random Forest
        0.90,  # Base SVM
        0.90   # Tuned SVM
    ],
    'F1-Score': [
        0.89,  # Logistic Regression
        0.89,  # Base Random Forest
        0.88,  # Tuned Random Forest
        0.90,  # Base SVM
        0.90   # Tuned SVM
    ]
}

# Convert to DataFrame
metrics_df = pd.DataFrame(model_metrics)

# Display the summary table
print(metrics_df)

# %% [markdown]
# Visualizing the comparison

# %%
# Plot grouped bar chart for metrics
metrics_to_plot = ['Accuracy', 'Precision', 'Recall', 'F1-Score']
x = np.arange(len(metrics_df['Model']))
bar_width = 0.15

for metric in metrics_to_plot:
    plt.figure(figsize=(10, 6))
    plt.bar(x, metrics_df[metric], bar_width, label=metric)
    plt.title(f'{metric} Comparison Across Models')
    plt.ylabel(metric)
    
    
    plt.ylim(0.85, 0.95)  
    
    plt.xticks(x, metrics_df['Model'], rotation=45)
    plt.grid(axis='y')
    plt.tight_layout()
    plt.show()

# %% [markdown]
# Confusion Matrix for all the models

# %%
# Logistic Regression
ConfusionMatrixDisplay.from_predictions(y_test, y_pred_test, display_labels=["Non-Failure", "Failure"], cmap="Blues")
plt.title("Confusion Matrix (Logistic Regression)")
plt.show()

# Base Random Forest
ConfusionMatrixDisplay.from_predictions(y_test, rf_y_pred_test, display_labels=["Non-Failure", "Failure"], cmap="Blues")
plt.title("Confusion Matrix (Base Random Forest)")
plt.show()

# Tuned Random Forest
ConfusionMatrixDisplay.from_predictions(y_test, rf_y_pred_test_revised, display_labels=["Non-Failure", "Failure"], cmap="Blues")
plt.title("Confusion Matrix (Tuned Random Forest)")
plt.show()

# Base SVM
ConfusionMatrixDisplay.from_predictions(y_test, svm_y_pred_test, display_labels=["Non-Failure", "Failure"], cmap="Blues")
plt.title("Confusion Matrix (Base SVM)")
plt.show()

# Tuned SVM
ConfusionMatrixDisplay.from_predictions(y_test, svm_y_pred_test_tuned, display_labels=["Non-Failure", "Failure"], cmap="Blues")
plt.title("Confusion Matrix (Tuned SVM)")
plt.show()

# %% [markdown]
# Conclusion

# %% [markdown]
# I compared five models: Logistic Regression, Base Random Forest, Tuned Random Forest, Base SVM, and Tuned SVM on their performance in predicting machine failures. The evaluation focused on accuracy, precision, recall, and F1-score for the target variable (fail), using the testing dataset.
# 
# Key Observations:
# 	1.	Base SVM achieved the highest overall accuracy (91%) and F1-score (90%) for the failure class, making it the strongest candidate for general performance.
# 	2.	Logistic Regression and Base Random Forest showed comparable performance, with accuracy and F1-scores of 89% for the failure class.
# 	3.	Tuned Random Forest slightly underperformed compared to the base Random Forest, possibly due to increased constraints during tuning.
# 	4.	Tuned SVM showed performance comparable to Base SVM but with a slightly lower recall for the failure class.
# 
# Final Model Selection:
# The Base SVM is selected as the final model due to:
# 	•	Its high accuracy and F1-score for the failure class.
# 	•	A balanced performance across all metrics, making it suitable for both failure detection and generalization.
# 
# Conclusion:
# The Base SVM model effectively balances precision and recall for the failure class, demonstrating its suitability for predictive maintenance tasks.


